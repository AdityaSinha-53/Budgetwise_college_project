================================================================
  BUDGETWISE — PERSONAL FINANCE TRACKER
  BCA Major Project  |  Final Submission Build  |  May 2026
================================================================

A multi-user, web-based personal finance management system that
enables users to record income and expenses, plan budgets, pursue
savings goals, attach digital copies of receipts, and analyse
their financial behaviour through monthly, category, and custom-
range reports. The system supports two user roles — regular users
who manage their own data, and administrators who oversee the
platform — and produces automatic notifications when budgets are
exceeded or savings goals reach milestones.

Built using HTML, CSS, JavaScript, PHP, and MySQL. Runs on XAMPP
with no external dependencies, no build tools, and no frameworks.

----------------------------------------------------------------
  PROJECT STRUCTURE AT A GLANCE
----------------------------------------------------------------

  Database Tables       : 12
  Functional Modules    : 10
  User-Facing Pages     : 20
  Handler Scripts       : 7
  User Roles            : 2 (regular user, administrator)
  Chart Visualisations  : Bar, doughnut, and line via Chart.js
  Export Formats        : CSV, Excel (.xls), PDF
  Themes                : Dark (default) and Light

----------------------------------------------------------------
  HOW TO RUN
----------------------------------------------------------------

  1. Install XAMPP   (https://www.apachefriends.org/)
  2. Copy the entire budget-app/ folder into:
        C:\xampp\htdocs\budget-app\
  3. Start "Apache" and "MySQL" from the XAMPP Control Panel.
  4. Open phpMyAdmin:  http://localhost/phpmyadmin
       - Click "Import"
       - Select database/setup.sql
       - Click "Go"
     (The setup script creates the database, all 12 tables,
     two seeded users, and sample data.)
  5. Make sure these upload directories exist and are writable:
        uploads/profile_images/
        uploads/receipts/
     XAMPP default permissions are usually adequate.
  6. Open the app in your browser:
        http://localhost/budget-app/
     The public landing page appears.
  7. Click "Sign In" and use one of the seeded accounts:

        Admin user   : username "admin"   password "admin123"
        Regular user : username "demo"    password "admin123"

     The admin sees the full sidebar including the Admin section;
     the regular user sees the standard eight modules.
     Change passwords from Profile > Change Password after first
     login, especially before any public deployment.

If you see a "Database Connection Failed" page, MySQL probably is
not running, or the database has not been imported yet. The error
page itself lists exact things to check when DEBUG is true, which
is the default in includes/db.php.

----------------------------------------------------------------
  FOLDER STRUCTURE
----------------------------------------------------------------

  budget-app/
  |
  +-- README.txt                       (this file)
  |
  +-- index.php                        (public landing page)
  +-- register.php                     (new user signup)
  +-- login.php                        (sign-in form)
  +-- forgot_password.php              (two-step password recovery)
  +-- logout.php                       (session teardown)
  +-- dashboard.php                    (authenticated overview)
  |
  +-- assets/
  |     +-- style.css                  (single stylesheet, 2 themes)
  |
  +-- includes/
  |     +-- db.php                     (connection + helpers + auth guard)
  |     +-- auth.php                   (role and permission helpers)
  |     +-- uploads.php                (receipt-attachment helpers)
  |     +-- header.php                 (sidebar + page top)
  |     +-- footer.php                 (page bottom + scripts)
  |
  +-- database/
  |     +-- setup.sql                  (schema + seed data)
  |
  +-- uploads/
  |     +-- profile_images/            (future profile picture support)
  |     +-- receipts/                  (transaction receipt images)
  |
  |  -- TRANSACTIONS --
  +-- view_transactions.php            (list with filters)
  +-- add_transaction.php              (add new)
  +-- edit_transaction.php             (edit existing)
  +-- delete_transaction.php           (handler)
  |
  |  -- CATEGORIES --
  +-- manage_categories.php            (list + add)
  +-- edit_category.php                (rename / re-type)
  +-- delete_category.php              (handler)
  |
  |  -- BUDGETS --
  +-- manage_budgets.php               (list + add by month/year)
  +-- edit_budget.php                  (limit update)
  +-- delete_budget.php                (handler)
  +-- budget_vs_actual.php             (comparison + notifications)
  |
  |  -- SAVINGS GOALS --
  +-- manage_goals.php                 (list with progress bars)
  +-- add_goal.php                     (create new goal)
  +-- edit_goal.php                    (contribute + edit, dual mode)
  +-- delete_goal.php                  (handler)
  |
  |  -- REPORTS --
  +-- monthly_report.php               (income vs expense per month)
  +-- category_report.php              (spending breakdown by category)
  +-- date_range_report.php            (custom-range report)
  +-- export_csv.php                   (CSV download)
  +-- export_excel.php                 (Excel .xls download)
  +-- export_pdf.php                   (browser print-to-PDF)
  |
  |  -- NOTIFICATIONS --
  +-- view_notifications.php           (inbox view)
  +-- notification_mark_read.php       (handler)
  +-- notification_delete.php          (handler)
  |
  |  -- PROFILE --
  +-- profile.php                      (read-only summary + statistics)
  +-- edit_profile.php                 (name, email, phone, goal)
  +-- change_password.php              (with current-password check)
  +-- settings.php                     (theme, currency, language, date)
  +-- payment_methods.php              (list + add)
  +-- payment_method_delete.php        (handler)
  |
  +-- ADMIN (admin role only)
  +-- admin_dashboard.php              (platform-wide aggregates)
  +-- manage_users.php                 (user list + activate/deactivate)
  +-- user_toggle.php                  (handler)
  +-- system_logs.php                  (audit log viewer)

----------------------------------------------------------------
  DATABASE SCHEMA — 12 TABLES
----------------------------------------------------------------

Identity and Access (3):
  - users           (login credentials, role, active flag)
  - user_profiles   (name, phone, profile image, monthly goal)
  - settings        (per-user theme, currency, language, date format)

Financial Records (4):
  - categories      (default and custom; income or expense)
  - payment_methods (default and custom; cash, UPI, card, etc.)
  - transactions    (unified — income and expense in one table)
  - budgets         (per-category monthly limits, scoped by period)

Goals and Attachments (2):
  - savings_goals   (target, saved, target date, status)
  - attachments     (receipt files linked to transactions)

System-Written Tables (3):
  - notifications   (alerts generated by budget/savings logic)
  - report_logs     (audit of every report viewed or exported)
  - admin_logs      (audit of every administrative action)

Foreign keys cascade where deletion of a user should remove their
data; they SET NULL where deletion of a category or payment method
should preserve the affected transactions with their tag cleared.

----------------------------------------------------------------
  THE 10 MODULES IN DETAIL
----------------------------------------------------------------

1. AUTHENTICATION
   register.php, login.php, logout.php, forgot_password.php
   Bcrypt password hashing (cost factor 12). Session regenerated
   on successful login, password change, and recovery. Two-step
   recovery flow uses username + email verification (no SMTP).

2. DASHBOARD & ANALYTICS
   dashboard.php
   Six summary cards (income, expense, balance, savings rate,
   monthly transactions, expense ratio), three Chart.js charts
   (category doughnut, monthly bar, savings line), and the six
   most recent transactions.

3. TRANSACTION MANAGEMENT
   view_transactions.php, add_transaction.php, edit_transaction.php
   Filter by type, category, payment method, date range, and
   free-text. Receipts can be attached at create time and
   replaced or removed at edit time. Files stored with random
   names under uploads/receipts/.

4. CATEGORY MANAGEMENT
   manage_categories.php, edit_category.php, delete_category.php
   Defaults are shared across users (user_id NULL). Custom
   categories belong to one user. Duplicate prevention by name
   and type within the user's visible set.

5. BUDGET MANAGEMENT
   manage_budgets.php, edit_budget.php, delete_budget.php,
   budget_vs_actual.php
   Budgets are period-scoped (month + year), allowing future
   and historical plans to coexist. Composite uniqueness ensures
   one budget per user per category per period. Comparison page
   triggers notification generation at 70% and 100% thresholds.

6. SAVINGS GOALS
   manage_goals.php, add_goal.php, edit_goal.php, delete_goal.php
   Each goal has a name, target, saved amount, target date, and
   status. The saved_amount is denormalised (updated on each
   contribution) for fast dashboard reads. Milestone notifications
   fire at 25%, 50%, 75%, and 100% completion.

7. REPORTS & ANALYTICS
   monthly_report.php, category_report.php, date_range_report.php,
   export_csv.php, export_excel.php, export_pdf.php
   Three reports plus three export formats. Each report logs its
   generation event to report_logs. PDF uses browser native
   print-to-PDF for zero dependencies.

8. NOTIFICATIONS
   view_notifications.php, notification_mark_read.php,
   notification_delete.php
   Unread alerts at the top, read alerts below. Bulk
   mark-all-as-read available. Unread count drives the sidebar
   badge through unread_notification_count() in db.php.

9. PROFILE MANAGEMENT
   profile.php, edit_profile.php, change_password.php,
   settings.php, payment_methods.php, payment_method_delete.php
   Separated into single-purpose pages. Password change requires
   verification of the current password. Settings update writes
   to the settings table and pushes the theme to a cookie.

10. ADMIN (admin role only)
    admin_dashboard.php, manage_users.php, user_toggle.php,
    system_logs.php
    Platform-wide aggregates and audit visibility. Cannot edit
    individual user records. Self-deactivation is blocked at two
    layers (UI omission and handler-side check).

----------------------------------------------------------------
  SECURITY POSTURE
----------------------------------------------------------------

  - Prepared statements on every database query via the db_one,
    db_all, db_run helpers — immune to SQL injection.
  - htmlspecialchars on every dynamic output — immune to XSS.
  - Bcrypt password hashing via password_hash and password_verify
    at cost factor 12.
  - Session cookies set with HttpOnly and SameSite=Lax flags.
  - Session ID regenerated on successful login, password change,
    and forgot-password recovery (defence against session
    fixation).
  - Role-based access control: require_admin() guards every
    admin page; non-admins redirected with a status banner.
  - IDOR defence: user_owns($conn, $table, $id) verifies record
    ownership before every edit or delete operation.
  - File upload defence (receipts):
       MIME whitelist (JPG/PNG/WebP)
       2 MB size limit
       Content-based type detection via finfo_file
       Randomised stored filenames (16-byte hex)
  - DEBUG constant gates verbose database error output for
    production deployment.
  - Self-deactivation block at two layers (UI omission and
    server-side enforcement in user_toggle.php).
  - Email enumeration prevented in forgot-password by using
    identical error messages regardless of which field
    mismatched.
  - Disabled-account auth guard: every authenticated request
    checks is_active and tears down the session if the account
    has been deactivated since login.

----------------------------------------------------------------
  THE 3 DB HELPERS  (defined in includes/db.php)
----------------------------------------------------------------

These hide mysqli's verbose prepared-statement boilerplate
behind one-line calls.

  db_one($conn, $sql, $types, $params)
      Run a SELECT, return the first row (or null).

  db_all($conn, $sql, $types, $params)
      Run a SELECT, return ALL rows as an array.

  db_run($conn, $sql, $types, $params)
      Run an INSERT, UPDATE, or DELETE. Returns true/false.

The "?" in SQL marks where a value will be inserted safely.
The "types" string says what data type each "?" is:

      "i" = integer       "s" = string       "d" = decimal

You combine letters in order. Two strings + one int = "ssi".

  EXAMPLES
  --------
  // Look up a user by username (one row or null)
  $u = db_one($conn,
      "SELECT id, password FROM users WHERE username=?",
      "s", [$username]);

  // List a user's filtered transactions (many rows)
  $rows = db_all($conn,
      "SELECT * FROM transactions WHERE user_id=? AND type=?
       ORDER BY txn_date DESC",
      "is", [$uid, $type]);

  // Add a new row
  db_run($conn,
      "INSERT INTO transactions
         (user_id, category_id, payment_method_id, title, amount, type, txn_date)
       VALUES (?, ?, ?, ?, ?, ?, ?)",
      "iiisdss", [$uid, $cat_id, $pm_id, $title, $amount, $type, $date]);

Two additional helpers complement these:

  db_last_id($conn)      Returns the auto-increment ID from
                         the most recent INSERT. Used to chain
                         related inserts across tables (e.g.
                         registration creates rows in users,
                         user_profiles, and settings using the
                         new user's ID).

The auth.php file adds role-aware helpers:

  current_user_id()      Returns the session user's ID.
  current_user_role()    Returns 'user' or 'admin'.
  is_admin()             Returns true for admins, used to
                         conditionally render UI.
  require_admin()        Redirects non-admins; called at the
                         top of admin pages.
  user_owns($conn, $table, $id)
                         Returns true if the current user owns
                         the record (or is admin). Used before
                         every edit and delete to defend against
                         IDOR attacks.
  log_admin_action($conn, $action, $target_id, $description)
                         Inserts a row into admin_logs.

----------------------------------------------------------------
  PHP, MYSQL, AND BROWSER CONCEPTS USED
----------------------------------------------------------------

PHP
  - Sessions (session_start, $_SESSION) for login state
  - session_set_cookie_params() with HttpOnly + SameSite=Lax
  - session_regenerate_id(true) at login, password change,
    and forgot-password recovery
  - password_hash and password_verify (bcrypt cost 12)
  - require_once for shared infrastructure (db.php, auth.php,
    header.php, footer.php)
  - Post/Redirect/Get pattern (prevents form resubmission)
  - htmlspecialchars on every dynamic output (XSS defence)
  - filter_var(FILTER_VALIDATE_EMAIL) for email validation
  - Server-side validation on every INSERT and UPDATE
  - File-upload security via $_FILES, finfo_file, and
    move_uploaded_file
  - bin2hex(random_bytes(16)) for randomised stored filenames
  - fputcsv for CSV export
  - Browser print dialog for PDF export (zero-dependency)
  - DEBUG constant for environment-aware error handling
  - No closing PHP tag in include files (prevents
    "headers already sent" errors)

MYSQL
  - 12 tables across 4 logical groups
  - ENUM types for fixed-value columns (type, role, status)
  - UNIQUE KEY constraints on users.username, users.email,
    and the composite (user_id, category_id, period_month,
    period_year) on budgets
  - Foreign keys with ON DELETE CASCADE on user-owned data
  - Foreign keys with ON DELETE SET NULL on category and
    payment_method references in transactions
  - INSERT ... ON DUPLICATE KEY UPDATE (atomic upsert) used
    for budgets and settings
  - LEFT JOIN to fetch transactions with optional category
    and payment method names
  - GROUP BY with DATE_FORMAT for monthly aggregates
  - SUM(CASE WHEN ...) for conditional totals in one query
  - COALESCE() to default NULL aggregates to 0
  - Prepared statements (?) bound with mysqli_stmt_bind_param
  - Indexes on txn_date, type, category_id, user_id, and
    composite indexes on filter-heavy columns

JAVASCRIPT
  - Vanilla JavaScript, no libraries
  - Chart.js loaded from CDN for dashboard and report charts
  - Cookie-persisted theme preference
  - Auto-dismiss of success/info banners with CSS transitions
  - Selective form validation feedback

CSS
  - Custom properties (variables) for theme system
  - [data-theme="..."] attribute selector for theme switching
  - CSS Grid + Flexbox for layout
  - @media queries at 900px and 550px for responsiveness
  - :focus-visible for keyboard accessibility
  - Responsive table scrolling on narrow screens

----------------------------------------------------------------
  KNOWN LIMITATIONS AND VIVA TALKING POINTS
----------------------------------------------------------------

  - No CSRF token protection. Since the project runs on XAMPP
    localhost and is a college submission, the cross-site
    attack surface is effectively zero. A public deployment
    should add CSRF tokens to every form and delete link.
  - No login throttling. A localhost demo does not need it,
    but a public deployment should add per-IP rate limiting.
  - No pagination on the transactions list. Fine for thousands
    of rows; slow at hundreds of thousands.
  - DB credentials live in plain text in includes/db.php.
    A real app would use environment variables (.env files).
  - Currency and language settings are stored in the schema
    but the current build displays all amounts as rupees
    regardless. Internationalisation work has a place to plug
    in without database changes.
  - PDF export uses the browser's print dialog rather than a
    library like TCPDF. This is a deliberate trade-off: zero
    dependency, identical visual output, one extra user click.
  - The print-to-PDF approach trades a library dependency for
    one user click. TCPDF integration is straightforward to
    add if a fully programmatic PDF pipeline is required.

----------------------------------------------------------------
  SAMPLE VIVA QUESTIONS AND ANSWERS
----------------------------------------------------------------

Q: Why did you use a single unified transactions table instead
   of separate Income and Expenses tables?
A: One table with a `type` column avoids schema duplication for
   what is logically the same entity differing only by direction
   of flow. Reports use a single SUM(CASE WHEN type=...) query
   per page rather than UNION-ing two tables. This design was
   explicitly recommended in the project specification because
   it is cleaner to query, cleaner to extend, and easier to
   defend in viva.

Q: What is the user_owns() function and why does every edit and
   delete handler call it?
A: It defends against Insecure Direct Object Reference (IDOR)
   attacks. Without it, a user could edit the URL parameter
   `edit_transaction.php?id=N` to access another user's record.
   The function checks the record's user_id column against the
   session user before any read or write proceeds. Admins
   bypass this check because they need to manage all records.

Q: How are receipt uploads secured?
A: Three layers of defence. MIME type is checked against a
   whitelist of JPG, PNG, and WebP. Size is capped at 2 MB.
   The actual content type is detected via finfo_file rather
   than trusting the browser-supplied $_FILES['type'] header,
   so a malicious .php file renamed to .jpg is still rejected
   because its real content type is detected as text/x-php.
   Stored filenames are randomised with bin2hex(random_bytes(16))
   to prevent path-traversal and overwrite attacks.

Q: How do budget notifications avoid spamming the user?
A: The budget_vs_actual.php page checks the notifications table
   for an existing notification with the same title before
   inserting. The title is unique per category and period
   ("Budget warning — Food for May 2026"), so the same alert
   never fires twice for the same threshold crossing. The same
   strategy is used by the savings goal milestone notifications.

Q: What is the difference between a kept, upgraded, and new
   table in the schema?
A: Five tables carry over from the original five-table build
   with user_id columns added — users, transactions, budgets,
   profile (renamed to user_profiles), and custom_categories
   (replaced and unified into categories). Seven tables are
   new: payment_methods, savings_goals, attachments,
   notifications, settings, report_logs, and admin_logs. All
   twelve tables now scope to the user_id foreign key, enabling
   multi-user isolation throughout the application.

Q: Why does admin_logs and report_logs exist as separate
   tables rather than one generic activity_log?
A: They serve different audiences and retention policies.
   admin_logs records administrative actions for accountability
   — who deactivated which user, when, from which IP. report_logs
   records analytics activity for usage measurement — which
   reports are most popular and at what cadence. Keeping them
   separate clarifies what each table is for and lets either
   be purged or archived independently.

Q: Why does db.php have no closing PHP tag at the end?
A: A closing ?> tag allows trailing whitespace (spaces,
   newlines) to be sent to the browser as output. Since db.php
   is included at the very top of every page, that whitespace
   arrives before any header() or setcookie() call. PHP then
   throws "headers already sent" errors that break login
   redirects, logout, session cookies, and CSV downloads.
   Omitting the closing tag is the standard practice for PHP
   include files.

Q: Why does the project use the browser's native print-to-PDF
   instead of a library like TCPDF?
A: Zero dependencies. TCPDF requires several megabytes of
   library code, font configuration for Unicode characters
   like the rupee symbol, and additional setup steps on every
   XAMPP install. The print-to-PDF approach produces output
   of equivalent quality because both ultimately use a browser
   engine to render PDF content. The trade-off is one extra
   user click in the print dialog, which is acceptable for a
   college project. The implementation is in export_pdf.php.

Q: What is denormalisation and where does this project use it?
A: Denormalisation is the deliberate inclusion of redundant
   data in a schema to improve read performance, accepting the
   trade-off of slightly more complex writes. This project uses
   it in savings_goals.saved_amount — the total is updated each
   time a contribution is recorded rather than computed from a
   separate contributions table on every read. Goals are
   displayed on the dashboard and goal-list pages frequently,
   so the read-side benefit substantially outweighs the
   write-side cost.

----------------------------------------------------------------
  CREDITS
----------------------------------------------------------------

Built as a BCA major project. Stack: HTML5, CSS3, PHP 8.x
(procedural), MySQL 8, MySQLi extension. JavaScript and Chart.js
for visualisations. No frameworks. No build tools. No external
PHP libraries.

Final implementation completed May 2026 following a structural
review, security audit, and full multi-user refactor.
